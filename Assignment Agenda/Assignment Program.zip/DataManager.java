interface DataManager
	{
	void addAssignment(Assignment assignment);
        
    void replaceAssignment(Assignment assignment, int index);
	}
