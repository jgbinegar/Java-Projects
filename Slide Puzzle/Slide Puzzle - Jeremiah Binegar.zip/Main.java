import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.lang.Math;
import java.text.*;
import java.io.*;
import java.util.*;

public class Main
{
    public static void main(String[] argv)
    {
        System.out.println("Starting Program...");
        new MyPuzzleFrame();
        System.out.println("Program Running...");
    }
}
